package com.example.newsnow;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.progressindicator.LinearProgressIndicator;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.IOException;
import java.util.ArrayList;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private RecyclerView recyclerView;
    private NewsRecyclerAdapter adapter;
    private LinearProgressIndicator progressIndicator;
    private SearchView searchView;
    private Button btn1, btn2, btn3, btn4, btn5, btn6, btn7;

    // Use your active API key; verify it on newsapi.org
    private final String API_KEY = "34d04c16cc9f4ea0ae8b73d315875866";
    private final String BASE_URL = "https://newsapi.org/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        recyclerView = findViewById(R.id.news_recycler_view);
        progressIndicator = findViewById(R.id.progress_bar);
        searchView = findViewById(R.id.search_view);
        btn1 = findViewById(R.id.btn_1);
        btn2 = findViewById(R.id.btn_2);
        btn3 = findViewById(R.id.btn_3);
        btn4 = findViewById(R.id.btn_4);
        btn5 = findViewById(R.id.btn_5);
        btn6 = findViewById(R.id.btn_6);
        btn7 = findViewById(R.id.btn_7);

        // Set click listeners for category buttons
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn7.setOnClickListener(this);

        // Setup SearchView listener
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                getNews("general", query);
                return true;
            }
            @Override
            public boolean onQueryTextChange(String newText) {
                return false;
            }
        });

        // Setup RecyclerView and adapter
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new NewsRecyclerAdapter(this);
        recyclerView.setAdapter(adapter);

        // Fetch initial news for 'general' category
        getNews("general", null);
    }

    @Override
    public void onClick(View v) {
        Button btn = (Button) v;
        // Convert button text to lowercase for API parameter
        String category = btn.getText().toString().toLowerCase();
        getNews(category, null);
    }

    private void getNews(String category, String query) {
        progressIndicator.setVisibility(View.VISIBLE);

        // Build the URL for top-headlines endpoint
        String url = BASE_URL + "v2/top-headlines?language=en&apiKey=" + API_KEY;
        if (category != null && !category.isEmpty()) {
            url += "&category=" + category;
        }
        if (query != null && !query.isEmpty()) {
            url += "&q=" + query;
        }
        Log.d("API URL", url);

        OkHttpClient client = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) " +
                        "AppleWebKit/537.36 (KHTML, like Gecko) " +
                        "Chrome/115.0.0.0 Safari/537.36")
                .build();

        new Thread(() -> {
            try {
                Response response = client.newCall(request).execute();
                String rawResponse = response.body().string();
                Log.d("RawResponse", rawResponse);

                // Check if response is HTML
                if (rawResponse.trim().startsWith("<!DOCTYPE")) {
                    runOnUiThread(() -> {
                        progressIndicator.setVisibility(View.INVISIBLE);
                        Log.e("API Failure", "Received HTML response instead of JSON");
                        Toast.makeText(MainActivity.this, "Error: Received HTML response", Toast.LENGTH_LONG).show();
                    });
                    return;
                }

                ArrayList<Article> articleList = new ArrayList<>();
                try {
                    JSONObject jsonObject = new JSONObject(rawResponse);
                    if ("error".equalsIgnoreCase(jsonObject.optString("status"))) {
                        String errorMsg = jsonObject.optString("message");
                        Log.e("API Error", errorMsg);
                        runOnUiThread(() -> {
                            progressIndicator.setVisibility(View.INVISIBLE);
                            Toast.makeText(MainActivity.this, "API Error: " + errorMsg, Toast.LENGTH_LONG).show();
                        });
                        return;
                    }
                    JSONArray articles = jsonObject.optJSONArray("articles");
                    if (articles != null && articles.length() > 0) {
                        for (int i = 0; i < articles.length(); i++) {
                            JSONObject articleObj = articles.getJSONObject(i);
                            String title = articleObj.optString("title", "No Title");
                            String urlArticle = articleObj.optString("url", "");
                            String urlToImage = articleObj.optString("urlToImage", "");
                            Article article = new Article(title, urlArticle, urlToImage);
                            articleList.add(article);
                        }
                    } else {
                        runOnUiThread(() -> {
                            progressIndicator.setVisibility(View.INVISIBLE);
                            Toast.makeText(MainActivity.this, "No articles found", Toast.LENGTH_SHORT).show();
                            adapter.updateData(new ArrayList<>());
                        });
                        return;
                    }
                    runOnUiThread(() -> {
                        progressIndicator.setVisibility(View.INVISIBLE);
                        adapter.updateData(articleList);
                    });
                } catch (JSONException e) {
                    runOnUiThread(() -> {
                        progressIndicator.setVisibility(View.INVISIBLE);
                        Log.e("JSON Parsing", "Error parsing JSON: " + e.getMessage());
                        Toast.makeText(MainActivity.this, "Error parsing news data", Toast.LENGTH_LONG).show();
                    });
                }
            } catch (IOException e) {
                runOnUiThread(() -> {
                    progressIndicator.setVisibility(View.INVISIBLE);
                    Log.e("API Failure", "IOException: " + e.getMessage());
                    Toast.makeText(MainActivity.this, "Network error", Toast.LENGTH_LONG).show();
                });
            }
        }).start();
    }
}
