package com.example.newsnow;

public class Article {
    public String title;
    public String url;
    public String urlToImage;

    public Article(String title, String url, String urlToImage) {
        this.title = title;
        this.url = url;
        this.urlToImage = urlToImage;
    }
}
