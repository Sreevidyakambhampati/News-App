package com.example.newsnow;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;
import java.util.List;

public class NewsRecyclerAdapter extends RecyclerView.Adapter<NewsRecyclerAdapter.ViewHolder> {

    private List<Article> articles = new ArrayList<>();
    private Context context;

    public NewsRecyclerAdapter(Context context) {
        this.context = context;
    }

    public void updateData(List<Article> articleList) {
        articles.clear();
        articles.addAll(articleList);
        notifyDataSetChanged();
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.news_recycler_row, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
        Article article = articles.get(position);
        holder.titleTextView.setText(article.title);
        if (article.urlToImage != null && !article.urlToImage.isEmpty()) {
            Picasso.get()
                    .load(article.urlToImage)
                    .placeholder(R.drawable.no_image_icon)
                    .error(R.drawable.no_image_icon)
                    .into(holder.imageView);
        } else {
            holder.imageView.setImageResource(R.drawable.no_image_icon);
        }

        // If URL is empty, disable click
        holder.itemView.setOnClickListener(v -> {
            if (article.url != null && !article.url.isEmpty()) {
                Intent intent = new Intent(context, NewsFullActivity.class);
                intent.putExtra("url", article.url);
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return articles.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView titleTextView;
        public ImageView imageView;
        public ViewHolder(View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.article_title);
            imageView = itemView.findViewById(R.id.article_image_view);
        }
    }
}
